#!/usr/bin/env python3
"""Independent read-only v18.53k reviewer; no physical IVPs.

Inputs: full source server sendback ZIP. This deliberately reconstructs
planar and third-SVD projection vectors from the 10D exported coordinates,
without using the original run_audit.py.
"""
from __future__ import annotations
import csv, hashlib, io, json, math, zipfile, sys
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'inputs/q550_residual_bivector_transverse_svd_direction_transport_fine_window_width_scan_boundary_attribution_v18_53k_bundle_server_sendback.zip'
OUT=ROOT/'results'
OUT.mkdir(exist_ok=True)

def tostr(f): return f.read().decode('utf-8')

def select(rows,seed,kappa,origin,width):
    a=[r for r in rows if r['seed']==seed and r['kappa_rule']==kappa and abs(float(r['origin_xi'])-origin)<1e-8 and abs(float(r['width_xi'])-width)<1e-8]
    if len(a)!=1: raise ValueError(f'expected one row: {(seed,kappa,origin,width)}, got {len(a)}')
    return a[0]

def arr(row,head): return np.array([float(row[f'{head}_{i:02d}']) for i in range(10)])
def cosine(a,b): return float(np.dot(a,b)/(np.linalg.norm(a)*np.linalg.norm(b)))

def main():
    with zipfile.ZipFile(SOURCE) as z:
        assert z.testzip() is None, 'archive CRC failure'
        roots={n.split('/')[0] for n in z.namelist() if '/' in n}
        assert len(roots)==1,roots
        base=next(iter(roots))+'/'
        counts={}
        for m in ('SOURCE_MANIFEST.json','OUTPUT_MANIFEST.json'):
            manifest=json.loads(z.read(base+m))
            for rel,digest in manifest['files'].items():
                real=hashlib.sha256(z.read(base+rel)).hexdigest()
                assert real==digest,(m,rel)
            counts[m]=len(manifest['files'])
        rows=list(csv.DictReader(io.StringIO(tostr(z.open(base+'results/fine_width_svd_geometry.csv')))))
        report=json.loads(z.read(base+'results/report.json'))
    assert len(rows)==756,len(rows)
    assert report['scientific_decision']=='AUTHENTIC_FINE_WIDTH_SCAN__NO_RESOLVED_SIGN_CROSSING'
    assert report['summary']['n_signed_coefficient_change_candidates']==0
    assert report['summary']['n_strong_near_closures']==420
    origins=[12.8,13.6,14.0,14.4,14.8,15.2]
    seeds=['original','autonomous']
    kappas=['original','autonomous','shared']
    comparison=[]
    anchors=[]
    for seed in seeds:
      for kappa in kappas:
       for origin in origins:
        left=select(rows,seed,kappa,origin,12.775)
        center=select(rows,seed,kappa,origin,12.8)
        right=select(rows,seed,kappa,origin,12.825)
        def split(r):
            net=arr(r,'net'); trans=arr(r,'transverse'); return net-trans,trans,net
        PL,TL,_=split(left); PC,TC,N=split(center); PR,TR,_=split(right)
        comparison.append(dict(seed=seed,kappa=kappa,origin_xi=origin,
             planar_left_right_cos=cosine(PL,PR),transverse_left_right_cos=cosine(TL,TR),
             planar_left_norm=float(np.linalg.norm(PL)),planar_center_norm=float(np.linalg.norm(PC)),
             planar_right_norm=float(np.linalg.norm(PR)),transverse_center_norm=float(np.linalg.norm(TC)),
             net_center_norm=float(np.linalg.norm(N)),
             center_cancellation_score=float(center['cancellation_score']),
             center_transverse_share_squared=float(center['rank3_share_of_net_squared'])))
        c=float(center['signed_rank3_coefficient']);s3=float(center['singular_value3'])
        anchors.append(dict(seed=seed,kappa=kappa,origin_xi=origin,relative_alignment_to_uniform_left_singular=c/(math.sqrt(3)*s3),
            singular_value1=float(center['singular_value1']),singular_value2=float(center['singular_value2']),
            singular_value3=s3, gap23=float(center['rank23_gap'])))
    # Check original exported split, emphasizing no new physical axis.
    max_scalar=0.0
    for row in rows:
       net=arr(row,'net'); t=arr(row,'transverse');p=net-t
       vals=[(float(np.linalg.norm(net)),float(row['R_total_norm'])),
             (float(np.linalg.norm(t)),float(row['rank3_net_norm'])),
             (float(np.linalg.norm(p)),float(row['rank2_net_norm']))]
       max_scalar=max(max_scalar,max(abs(a-b) for a,b in vals))
    assert max_scalar<1e-11,max_scalar
    assert all(x['planar_left_right_cos']<0 and x['transverse_left_right_cos']>0 for x in comparison)
    errors=[r for r in rows if r['endpoint_derivative_scaled_error']]
    local=[float(r['endpoint_derivative_scaled_error']) for r in errors if 12.725<=float(r['width_xi'])<=12.875]
    overall=[float(r['endpoint_derivative_scaled_error']) for r in errors]
    w12=[r for r in rows if abs(float(r['width_xi'])-12.8)<1e-10]
    summary={
      'input_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
      'verified_manifest_entries':counts,
      'decision':report['scientific_decision'],
      'n_triplets':len(rows),'n_strong_near_closures':report['summary']['n_strong_near_closures'],
      'n_sign_changes':report['summary']['n_signed_coefficient_change_candidates'],
      'max_exported_vector_norm_reconstruction_error':max_scalar,
      'all_36_comparisons_planar_opposite_transverse_concordant':True,
      'min_planar_cos':min(v['planar_left_right_cos'] for v in comparison),
      'max_planar_cos':max(v['planar_left_right_cos'] for v in comparison),
      'min_transverse_cos':min(v['transverse_left_right_cos'] for v in comparison),
      'max_transverse_cos':max(v['transverse_left_right_cos'] for v in comparison),
      'max_endpoint_ftc_scaled_error_full_grid':max(overall),
      'max_endpoint_ftc_scaled_error_fine_symmetric_segment':max(local),
      'max_svd_right_v3_line_angle_to_anchor_deg':max(float(r['v3_plane_angle_to_anchor_deg']) for r in rows),
      'minimum_adjacent_abs_v3_cosine':min(float(r['adjacent_abs_v3_cosine']) for r in rows),
      'min_sigma2_sigma3_gap':min(float(r['rank23_gap']) for r in rows),
      'min_signed_coefficient':min(float(r['signed_rank3_coefficient']) for r in rows),
      'max_signed_coefficient':max(float(r['signed_rank3_coefficient']) for r in rows),
      'anchor_third_share_min':min(float(r['rank3_share_of_net_squared']) for r in w12),
      'anchor_third_share_max':max(float(r['rank3_share_of_net_squared']) for r in w12),
      'anchor_uniform_left_alignment_min':min(v['relative_alignment_to_uniform_left_singular'] for v in anchors),
      'anchor_uniform_left_alignment_max':max(v['relative_alignment_to_uniform_left_singular'] for v in anchors),
      'interpretation_limits':['Planar and transverse vectors depend on the moving SVD decomposition.',
        'Opposition of projected planar vectors is not an independent material reversal.',
        'Near-uniform left singular vector at 12.8 is algebraically expected for near-equilateral triples.',
        'The maximum FTC finite-difference discrepancy occurs at uneven-width stencils, not in the local nearly symmetric scan.']
    }
    def csvout(fn,arr):
        with (OUT/fn).open('w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(arr[0]));w.writeheader();w.writerows(arr)
    csvout('planar_transverse_orientation_comparisons.csv',comparison)
    csvout('svd_anchor_uniform_left_alignment.csv',anchors)
    (OUT/'independent_review.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
    chosen=sorted([r for r in rows if r['seed']=='original' and r['kappa_rule']=='shared' and abs(float(r['origin_xi'])-14.4)<1e-10 and 12.6<=float(r['width_xi'])<=13.0],key=lambda r:float(r['width_xi']))
    w=[float(x['width_xi']) for x in chosen]
    fig,ax=plt.subplots(figsize=(8,4.6))
    ax.plot(w,[float(x['rank2_net_norm']) for x in chosen],'.-',label='Planar residual |P|')
    ax.plot(w,[float(x['rank3_net_norm']) for x in chosen],'.-',label='Transverse residual |T|')
    ax.axvline(12.8,ls=':',color='gray',lw=1)
    ax.set(xlabel='Window width Δξ',ylabel='10D bivector Frobenius-isometric norm',title='v18.53k independent split | origin 14.4 · original seed · shared κ₀')
    ax.grid(alpha=.25);ax.legend();fig.tight_layout();fig.savefig(OUT/'independent_planar_transverse_norms.png',dpi=160);plt.close(fig)
    fig,ax=plt.subplots(figsize=(8,4.6))
    for origin in origins:
        a=[v for v in comparison if v['origin_xi']==origin and v['seed']=='original' and v['kappa']=='shared'][0]
        ax.scatter([origin],[a['planar_left_right_cos']],marker='o')
        ax.scatter([origin],[a['transverse_left_right_cos']],marker='x')
    ax.axhline(0,color='gray',lw=1);ax.set_ylim(-1.1,1.1)
    ax.set(xlabel='Origin ξ',ylabel='Cosine across width 12.775 → 12.825',title='Projected-planar opposition vs. transverse concordance')
    ax.text(13.1,-.86,'circles: planar',fontsize=9);ax.text(13.1,.87,'crosses: transverse',fontsize=9)
    ax.grid(alpha=.25);fig.tight_layout();fig.savefig(OUT/'independent_planar_vs_transverse_orientation.png',dpi=160);plt.close(fig)
    print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
