# Q550 — v18.53k independent review of the physical server sendback

**Scope:** Independent, read-only postprocessing of the original authenticated Q550 v18.53k server return. Does **not** re-integrate the physical IVPs. Includes the unchanged source ZIP, its SHA-256, an independently written Python reviewer, row-by-row 10D projection reconstruction, validation JSON, two figures and this README.

## Reproduce

```bash
python3.13 -m pip install numpy matplotlib
python3.13 scripts/review_v18_53k.py
```

The reviewer verifies ZIP CRC, the 48 SHA-256 source entries and the 65 SHA-256 output entries before reading the 756-triplet CSV. It reconstructs the 10D norm decomposition for each row without calling the audit's SVD implementation and compares the projected-planar remainder P=N-T and rank-three component T across widths 12.775 and 12.825, for each of 2 seeds × 3 κ0 rules × 6 origins. It calculates the left-singular uniform-direction alignment using the SVD identity. It writes all aggregate quantities and comparative CSVs into `results/`.

## Independent findings

- Server decision: `AUTHENTIC_FINE_WIDTH_SCAN__NO_RESOLVED_SIGN_CROSSING`.
- Count: 10 physical IVPs according to the authenticated server report (6 primary + 4 refinements), 756 width-triplets; 420 of 756 score ≥0.9, zero qualifying signed-coefficient changes.
- All 36 adjacent-width comparisons: `cos(P(12.775),P(12.825))<0`, range [-0.9982914,-0.5845452]. Meanwhile `cos(T(12.775),T(12.825))>0`, range [0.9755454,0.9997745]. The comparison uses a *fixed Frobenius-isometric bivector-coordinate embedding* while the SVD projector depends on width.
- At width 12.8, the squared-share of total residual in the third singular direction is 98.3879%–99.7948% across origins/seeds/kappas. The alignment `|n·v3|/(sqrt(3)*sigma3)` ranges from 0.9999453 to 0.9999954, explaining the near-third-direction-only sum as a symmetry property of a nearly balanced triplet rather than discovering a physical extra axis.
- For origin 14.4, original seed, shared κ0, width 12.8, the planar residual is ~0.006903 and third-direction residual ~0.080959, total ~0.081253.
- All 756 right-singular third directions are reported well-conditioned for the predeclared σ3/σ1 and relative (σ2-σ3)/σ2 criteria; minimum relative second–third gap is 0.81876; minimum adjacent absolute line cosine is 0.77448.
- The reported global maximum FTC derivative finite-difference discrepancy is **0.1922959** (19.23%), whereas the maximum within the fine nearly-symmetric segment 12.725–12.875 is **0.0009106** (0.0911%). The coarse, unevenly spaced width finite-difference stencils have a bias; the global derivative discrepancy must not be hidden by the fine-local agreement. No corrected full-grid FTC tolerance has been certified by this review.

## Strict interpretation limits

1. These are integrated torque **bivector-coordinate** vectors, not independent physical spatial axes.
2. A sign difference of projected planar P vectors does not establish a material reversal, because the rank-3 SVD projector is width-dependent.
3. The total 3-window integral changes with width exactly according to the fundamental theorem of calculus's endpoint formula; this is an algebraic/calculus fact, not evidence of physical memory or holonomy.
4. The third-share near unity is natural for a nearly equilateral planar trio plus a small common out-of-plane bias; it is not an independent memory certificate.
5. The model time variable after ξ=25.6 is a formal continuation of the authenticated external clock, not a separately observed physical history.

**Next discriminating audit:** Hold a fixed observer-frame decomposition (or transport it by an independently defined dynamical connection) and test the same width-driven planar opposition. Quantify changes in the moving SVD projector separately from changes of the physical net torque integral, with corrected nonuniform-grid FTC derivatives.
