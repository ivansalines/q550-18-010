#!/usr/bin/env python3
"""Plot results reconstructed independently from server CSV exports. No IVP."""
from pathlib import Path
import csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=Path(__file__).resolve().parents[1];p=root/'results'
with (p/'opposition_cosines_by_origin.csv').open() as f:rows=list(csv.DictReader(f))
x=np.array([float(r['origin_xi']) for r in rows])
series=[('fixed_planar_cosine_mean','Fixed plane'),('moving_planar_cosine_mean','Moving SVD plane'),('model_planar_ambient_cosine_mean','Radial model (ambient)'),('model_planar_pullback_cosine_mean','Radial model (pullback)')]
fig,ax=plt.subplots(figsize=(8,4.8),layout='constrained')
for key,label in series:ax.plot(x,[float(r[key]) for r in rows],marker='o',label=label)
ax.axhline(-.9,linestyle='--',color='gray',label='Strong opposition threshold')
ax.set_ylim(-1.05,-.48);ax.grid(alpha=.2);ax.set_xlabel('Origin xi');ax.set_ylabel('Projected cosine, widths 12.775 vs 12.825');ax.set_title('v18.53l: Observer-comparison robustness');ax.legend(fontsize=8)
fig.savefig(p/'opposition_by_origin_independent.png',dpi=140);plt.close(fig)
with (p/'local_linear_nearnull_estimates.csv').open() as f:rows=list(csv.DictReader(f))
agg={}
for r in rows:agg.setdefault(float(r['origin_xi']),[]).append(r)
fig,ax=plt.subplots(figsize=(8,4.8),layout='constrained')
x=sorted(agg); y=[np.mean([float(r['predicted_minimum_norm']) for r in agg[o]]) for o in x]
ax.plot(x,y,marker='o',label='Local linear minimum residual norm')
ax.grid(alpha=.2);ax.set_xlabel('Origin xi');ax.set_ylabel('Linearized fixed-plane norm at optimal width');ax.set_title('v18.53l: Exploratory local near-null estimate (not certified)');ax.legend()
fig.savefig(p/'nearnull_by_origin_independent.png',dpi=140);plt.close(fig)
