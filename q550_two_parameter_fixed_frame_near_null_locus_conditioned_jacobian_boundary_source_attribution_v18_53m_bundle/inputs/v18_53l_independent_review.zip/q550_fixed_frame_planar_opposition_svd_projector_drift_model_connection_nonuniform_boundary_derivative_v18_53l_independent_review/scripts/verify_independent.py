#!/usr/bin/env python3
"""Independent lightweight v18.53l review. Does NOT execute Q550 IVPs.
Checks both SHA manifests and recomputes projected-vector cosines from archived
10D vectors, plus descriptive group and near-null diagnostics.
"""
import sys,json,hashlib,csv,zipfile,io,collections,math
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
SRC=next((ROOT/'source').glob('*server_sendback.zip'))
DEST=ROOT/'results'

def h(b):return hashlib.sha256(b).hexdigest()
def read_csv(z,name):return list(csv.DictReader(io.StringIO(z.read(name).decode('utf-8'))))
def to_float(x):return float(x)
def vec(row,p):return np.array([float(row[f'{p}_{i:02d}']) for i in range(10)])
def cos(a,b):return float(np.dot(a,b)/(np.linalg.norm(a)*np.linalg.norm(b)))
def write_csv(path,rows):
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,rows[0].keys());w.writeheader();w.writerows(rows)

def main():
    with zipfile.ZipFile(SRC) as z:
        assert z.testzip() is None,'CRC FAIL'
        roots={s.split('/')[0] for s in z.namelist() if '/' in s};assert len(roots)==1
        prefix=next(iter(roots))+'/'
        checked={}
        for mf in ('SOURCE_MANIFEST.json','OUTPUT_MANIFEST.json'):
            m=json.loads(z.read(prefix+mf))['files']
            bad=[n for n,dig in m.items() if h(z.read(prefix+n))!=dig]
            assert not bad,(mf,bad)
            checked[mf]=len(m)
        report=json.loads(z.read(prefix+'results/report.json'))
        rows=read_csv(z,prefix+'results/three_plane_comparison.csv')
        opp=read_csv(z,prefix+'results/fixed_vs_moving_vs_model_opposition.csv')
        secants=read_csv(z,prefix+'results/exact_secant_boundary_vs_projector_drift.csv')
        boundary=read_csv(z,prefix+'results/nonuniform_endpoint_derivative.csv')
        assert len(rows)==756 and len(opp)==36 and len(secants)==2160 and len(boundary)==1440
        assert report['new_actual_Q550_ivps']==10 and report['parent_k_authentic']
        assert h(z.read(prefix+'inputs/v18_53k_authenticated_server_sendback.zip'))==report['parent_k_pin_sha256']
        with zipfile.ZipFile(io.BytesIO(z.read(prefix+'inputs/v18_53k_authenticated_server_sendback.zip'))) as parent:
            assert parent.testzip() is None
        idx={(r['seed'],r['kappa_rule'],float(r['origin_xi']),float(r['width_xi'])):r for r in rows}
        check=[];cos_by_origin=[];fits=[]
        summary=collections.defaultdict(lambda: collections.defaultdict(list))
        cfields={'fixed_planar_cosine':'fixed_planar','moving_planar_cosine':'moving_planar',
                 'model_planar_ambient_cosine':'model_planar','model_planar_pullback_cosine':'model_pullback'}
        for o in opp:
            k=(o['seed'],o['kappa_rule'],float(o['origin_xi']))
            a=idx[k+(12.775,)];b=idx[k+(12.825,)]; mid=idx[k+(12.8,)]
            item={'seed':k[0],'kappa_rule':k[1],'origin_xi':k[2]}
            for f,p in cfields.items():
                v=cos(vec(a,p),vec(b,p))
                assert abs(v-float(o[f]))<2e-12,(k,f,v,o[f])
                item[f]=v
                summary[k[2]][f].append(v)
            # First-order local prediction: minimum norm of the tangent line to
            # the projected 10-vector. Not a certified actual zero crossing.
            vmid=vec(mid,'fixed_planar')
            vprime=(vec(b,'fixed_planar')-vec(a,'fixed_planar'))/.05
            offset=-float(np.dot(vmid,vprime)/np.dot(vprime,vprime))
            estimate=vmid+offset*vprime
            fits.append({'seed':k[0],'kappa_rule':k[1],'origin_xi':k[2],
                         'width_of_linear_minimum':12.8+offset,
                         'predicted_minimum_norm':float(np.linalg.norm(estimate)),
                         'sampled_minimum_norm':min(float(v['fixed_norm']) for key,v in idx.items() if key[:3]==k),
                         'sampled_minimum_width':min((float(v['fixed_norm']),float(v['width_xi'])) for key,v in idx.items() if key[:3]==k)[1]})
            check.append(item)
        assert sum(x['fixed_planar_cosine']<-.9 for x in check)==30
        for ori,dd in sorted(summary.items()):
            line={'origin_xi':ori}
            for f,values in dd.items():
                line[f+'_mean']=float(np.mean(values));line[f+'_min']=min(values);line[f+'_max']=max(values)
            cos_by_origin.append(line)
        for n in (3,5):
            errors=[float(x['scaled_derivative_error']) for x in boundary if int(x['stencil_nodes'])==n]
            assert abs(max(errors)-report['summary']['boundary_derivative_errors'][str(n)]['global_max_scaled_error'])<1e-12
        max_secant=max(float(x['exact_product_rule_error']) for x in secants)
        assert abs(max_secant-report['summary']['max_exact_secant_identity_error'])<1e-13
        results={'archive_sha256':h(SRC.read_bytes()),'manifest_checks':checked,
                 'parent_pin_sha256':report['parent_k_pin_sha256'],
                 'rows':len(rows),'opposition_pairs':len(opp),'secants':len(secants),'boundary_stencils':len(boundary),
                 'cosine_reconstruction':'36*4 independently reproduced at <2e-12 absolute error',
                 'strong_fixed_antiopposition':sum(x['fixed_planar_cosine']<-.9 for x in check),
                 'strong_moving_antiopposition':sum(x['moving_planar_cosine']<-.9 for x in check),
                 'strong_model_pullback_antiopposition':sum(x['model_planar_pullback_cosine']<-.9 for x in check),
                 'all_cosines_negative':all(x[f]<0 for x in check for f in cfields),
                 'max_secant_product_identity_error':max_secant,
                 'max_boundary_interval_additivity_error':max(float(x['boundary_integral_reconciliation_error']) for x in secants),
                 'max_model_drift_ratio':max(float(x['drift_to_source_ratio']) for x in secants if x['plane_choice']=='model_transported'),
                 'max_svd_drift_ratio':max(float(x['drift_to_source_ratio']) for x in secants if x['plane_choice']=='svd_moving'),
                 'min_pair_rank2_gap':min(float(x['pair_rank2_gap_min_relative']) for x in opp),
                 'important_limit':'All near-null estimates are local tangent-line predictions, not certified roots. Source/FTC identities use the same interval accumulator.'}
        write_csv(DEST/'independently_reconstructed_pair_cosines.csv',check)
        write_csv(DEST/'opposition_cosines_by_origin.csv',cos_by_origin)
        write_csv(DEST/'local_linear_nearnull_estimates.csv',fits)
        (DEST/'independent_report.json').write_text(json.dumps(results,indent=2)+'\n')
        print(json.dumps(results,indent=2))
if __name__=='__main__':main()
