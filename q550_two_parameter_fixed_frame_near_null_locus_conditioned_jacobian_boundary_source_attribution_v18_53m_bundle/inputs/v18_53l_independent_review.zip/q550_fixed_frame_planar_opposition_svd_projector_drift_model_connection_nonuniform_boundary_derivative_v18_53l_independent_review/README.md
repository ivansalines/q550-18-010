# Q550 v18.53l — Independent fixed-plane opposition and near-null review

This is a **lightweight independent postprocessing review** of the **unaltered** v18.53l user server sendback stored in `source/`. No physical IVPs were run locally, and no new physical observation is claimed. All interpretation and source-code documentation in English.

## Reproduce

```bash
python3.13 scripts/verify_independent.py
python3.13 scripts/plot_review.py
```

Python dependencies: `numpy`, `matplotlib` (only for plots). Original sendback has its own full genealogy and server runtime scripts.

## Independently reproduced results

- ZIP integrity and both authenticated manifests: source 15/15; output 28/28.
- Parent v18.53k archive pin checked; nested archive CRC passes.
- Archived table row counts: 756 width rows, 36 paired contrasts, 2,160 secant rows, 1,440 finite-difference rows.
- All 144 paired cosine values recalculated independently from the 10D output vectors, agreeing to better than 2e-12.
- Strong anti-opposition at `cos<-0.9` in 30/36 groups for each fixed, moving, and model-pullback comparison. **All 36** have negative cosines for all four observers.
- Exactly six weaker cases all occur at origin `xi=13.6`, not distributed between seeds/kappa rules.
- The fixed-plane minimum norm does not vanish on sampled nodes. A local linearized approximation predicts a near-null width around 12.804–12.814, depending on origin. This is NOT a certified continuous root, sign change in 10D, or physical flip.
- Median and peak model-projection drift are geometric and are not material-energy shares.
- The exact midpoint product identity and integral-additivity check are numerical/algebraic self-consistency tests (both using the same accumulated integral). These are not independent proofs of physical dynamics.
- The model radial SO(5) connection is a declared kinematic gauge, not a uniquely demonstrated material connection.

## Scientific note for next audit

The 2D projected net vector is close to a **two-parameter near-null locus** in `(origin xi, window width xi)` rather than a proven one-parameter zero crossing. Interpolated minima are lowest around origin `xi=15.2`, width about `12.8095`, but a real root requires direct continuous interpolation and a two-variable Jacobian with independent refinement and fixed/transported observer controls.

## Artifact inventory

- `source/*server_sendback.zip`: exact user-supplied original archive, not repacked internally.
- `scripts/verify_independent.py`: manifest verification, cosine recomputation, local linear near-null analysis.
- `scripts/plot_review.py`: generated visual diagnostics.
- `results/*.csv`: reconstructed contrasts and near-null estimates.
- `results/independent_report.json`: verification summary.
- `SOURCE_SHA256.json`: SHA256 manifest for this review pack excluding itself.
