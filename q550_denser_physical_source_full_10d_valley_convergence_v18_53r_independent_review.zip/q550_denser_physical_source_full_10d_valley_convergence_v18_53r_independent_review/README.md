# Q550 v18.53r — Independent Dense-Source Convergence Review

## Scope

This review authenticates and independently checks the original v18.53r server return. No Q550 11D integration was run locally. All physical trajectories and numerical tables originate from the unmodified `source_sendback.zip` (stored byte-for-byte in this review).

## Validation

- Outer sendback: ZIP CRC PASS, 12/12 source hashes and 10/10 output hashes PASS.
- Nested authenticated genealogy: v18.53q (12/12 sources, 9/9 outputs), v18.53p (14/14, 9/9), v18.53o (14/14, 11/11), all CRC PASS. Older dynamical ancestors are retained within the original nested source ZIP but not independently rechecked by this small script.
- Actual new physical trajectories: 12, in six original/autonomous seed and κ0-rule combinations at 2× and 4× density.
- Independent array/CSV geometry: 36/36 reconstructed 10D unit-direction polygon arclengths and 45-component oriented polygon integrals, and 36/36 cross-density comparisons.
- Historical baseline 1× is inherited rather than re-integrated.

## Main results

1. All 36 width curves are monotone, with zero branch switches and zero bounded optima.
2. Maximum 2×–4× differences: optimized width 1.46405e-6; integrated oriented form direction 0.004222816°; direct geodesic arclength 1.277964e-5 radians; minimum 10D residual norm 1.69809e-6.
3. Direct geodesic arclength is approximately 2.02919–2.02955 radians at 4× across all seed/κ0/method combinations. Minimum 10D residual is positive, 0.07869049 or greater for 4×.
4. Median ratio of 1×–2× to 2×–4× differences is about 3.92 for arclength, 3.95 for width, 4.03 for oriented-angle disagreement, 4.00 for the norm. This is consistent with second-order grid error, **not** a rigorous rate or a physical effect.
5. **Important field interpretation:** The server report field `max_source_difference_2x4x` equals the maximum *scaled 11D state difference* from the `physical_11d_integrations.csv` column. Independently evaluating the actual ten-component physical source at common knots gives maximum absolute component difference 1.03417e-13 and maximum vector-norm difference 1.31357e-13. The state-scaled figure is 2.13607e-13.
6. Maximum 2×–4× cumulative primitive component difference at matched knots is 5.78356e-6. Source-integration nodal drift reduces from 1.62055e-7 (2×) to 4.05144e-8 (4×). This suggests accumulated numerical integration/quadrature dominates the remaining reconstructed valley difference once the state/source agree.

## Reproduction

Extract this archive, then run:

```bash
python3 scripts/independent_verify_v18_53r.py inputs/source_sendback.zip outputs/reproduced
```

Requirements: Python 3.11+, NumPy and pandas (no Q550 solver or SciPy required). The validation script computes the file hash, verifies every local manifest entry, reconstructs geodesic angular lengths and oriented wedges directly from 10D unit vectors, and reports common-knot physical source/primitive/state differences. It **does not reintegrate** the 11D equations; the authentic execution is preserved in `source_sendback.zip`.

## Interpretation limits

The metric is Euclidean on ten bivector coordinates, not a demonstrated full-state physical metric. Measurements beyond ξ=25.6 are on formal model-clock continuation. Successive finite-density checks are not certified continuous-time error bounds; they cannot certify physical holonomy, material return, or a new dynamical invariant. All files and comments here are in English.
