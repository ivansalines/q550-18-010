#!/usr/bin/env python3
"""Independent v18.53r geometric checks using the unmodified server sendback.

Requires numpy and pandas. This script only audits archived arrays and CSVs;
it does not re-integrate Q550 equations. All comments/report content are English.
"""
import io
import json
import zipfile
import hashlib
import sys
from pathlib import Path

import numpy as np
import pandas as pd

DEFAULT_NAME = 'q550_denser_physical_source_sampling_full_10d_valley_oriented_transport_convergence_v18_53r_bundle_server_sendback.zip'

def sha(blob):
    return hashlib.sha256(blob).hexdigest()

def read_csv(z, path):
    return pd.read_csv(io.BytesIO(z.read(path)))

def stable_arclength(u):
    return np.sum(2*np.arctan2(np.linalg.norm(u[1:]-u[:-1],axis=1),
                                np.linalg.norm(u[1:]+u[:-1],axis=1)))

def oriented_polygon(u):
    i,j=np.triu_indices(u.shape[1],1)
    angles=2*np.arctan2(np.linalg.norm(u[1:]-u[:-1],axis=1),
                        np.linalg.norm(u[1:]+u[:-1],axis=1))
    wedge=u[:-1,i]*u[1:,j]-u[:-1,j]*u[1:,i]
    return np.sum(wedge/np.sinc(angles/np.pi)[:,None],axis=0)

def main(path):
    input_path=Path(path)
    if not input_path.is_file(): raise FileNotFoundError(input_path)
    with zipfile.ZipFile(input_path) as z:
        bad_zip=z.testzip()
        if bad_zip: raise RuntimeError('CRC failure '+bad_zip)
        prefix=z.namelist()[0].split('/')[0]+'/'
        manifest_counts={}
        for fname in ('SOURCE_MANIFEST.json','OUTPUT_MANIFEST.json'):
            entries=json.loads(z.read(prefix+fname))['files']
            failures=[name for name,digest in entries.items() if sha(z.read(prefix+name))!=digest]
            if failures: raise RuntimeError(f'{fname}: SHA256 failures {failures}')
            manifest_counts[fname]=len(entries)
        paths={key: prefix+'results/'+key+'.csv' for key in ['full10d_valley_convergence','cross_density_comparison','physical_11d_integrations','source_knot_convergence','full10d_valley_samples']}
        f=read_csv(z,paths['full10d_valley_convergence'])
        cross=read_csv(z,paths['cross_density_comparison'])
        phys=read_csv(z,paths['physical_11d_integrations'])
        source=read_csv(z,paths['source_knot_convergence'])
        samples=read_csv(z,paths['full10d_valley_samples'])
        znp=np.load(io.BytesIO(z.read(prefix+'results/dense_11d_10d_primitives.npz')))
        checks=[]
        for row in f.itertuples():
            tag=f'{row.seed}__{row.kappa_rule}__x{row.density_factor}__{row.method}'
            u=znp[tag+'__u10d']
            width=znp[tag+'__widths']
            norms=np.linalg.norm(u,axis=1)
            arc=stable_arclength(u)
            orient=oriented_polygon(u)
            stored=znp[tag+'__oriented_polygon45d']
            checks.append({'seed':row.seed,'kappa_rule':row.kappa_rule,'factor':row.density_factor,'method':row.method,
                           'max_unit_norm_error':float(np.max(np.abs(norms-1))),
                           'arc_error':float(abs(arc-row.arclength_direct)),
                           'oriented_polygon45_error':float(np.max(np.abs(orient-stored))),
                           'width_center_error':float(abs(width[len(width)//2]-row.width_center))})
        checks=pd.DataFrame(checks)
        if checks.max_unit_norm_error.max()>1e-11 or checks.arc_error.max()>1e-11 or checks.oriented_polygon45_error.max()>1e-11:
            raise RuntimeError('Array/CSV geometric replay inconsistent')
        state_source=[]
        for seed in ('original','autonomous'):
            for rule in ('shared','original','autonomous'):
                prefix_key=f'{seed}__{rule}'
                g2=znp[prefix_key+'__x2__g10d'];g4=znp[prefix_key+'__x4__g10d']
                C2=znp[prefix_key+'__x2__C10d'];C4=znp[prefix_key+'__x4__C10d']
                Z2=znp[prefix_key+'__x2__z11d'];Z4=znp[prefix_key+'__x4__z11d']
                X2=znp[prefix_key+'__x2__xi'];X4=znp[prefix_key+'__x4__xi']
                if not np.array_equal(X2,X4[::2]): raise RuntimeError('Common knots do not align')
                state_source.append({'seed':seed,'kappa_rule':rule,
                   'g_max_component_abs_2x4x':float(np.max(np.abs(g2-g4[::2]))),
                   'g_max_vector_norm_2x4x':float(np.max(np.linalg.norm(g2-g4[::2],axis=1))),
                   'C_max_component_abs_2x4x':float(np.max(np.abs(C2-C4[::2]))),
                   'Z11_max_scaled_2x4x':float(np.max(abs(Z2-Z4[::2])/np.maximum(1,abs(Z4[::2]))))})
        state_source=pd.DataFrame(state_source)
        verification=[]
        for row in cross.itertuples():
            ta=f'{row.seed}__{row.kappa_rule}__x{row.level_a}__{row.method}'
            tb=f'{row.seed}__{row.kappa_rule}__x{row.level_b}__{row.method}'
            ua=znp[ta+'__u10d'];ub=znp[tb+'__u10d']
            wa=znp[ta+'__widths'];wb=znp[tb+'__widths']
            aa=znp[ta+'__oriented_polygon45d'];bb=znp[tb+'__oriented_polygon45d']
            cos=np.clip(ua*ub,-1,1).sum(axis=1) # recalculated below from full dot
            max_angle=np.rad2deg(np.arccos(np.clip(np.sum(ua*ub,axis=1),-1,1))).max()
            area_angle=np.rad2deg(np.arccos(np.clip(np.dot(aa,bb)/np.linalg.norm(aa)/np.linalg.norm(bb),-1,1)))
            verification.append({'seed':row.seed,'kappa_rule':row.kappa_rule,'method':row.method,'a':row.level_a,'b':row.level_b,
              'width_diff_error':float(abs(np.max(np.abs(wa-wb))-row.max_width_absolute_difference)),
              'angle_error_deg':float(abs(max_angle-row.max_unit_direction_angle_deg)),
              'area_angle_error_deg':float(abs(area_angle-row.oriented_area_angle_deg))})
        verification=pd.DataFrame(verification)
        if (verification[['width_diff_error','angle_error_deg','area_angle_error_deg']].max()>1e-8).any():
            raise RuntimeError('Cross comparison replay discrepancy')
        ratios={}
        for column in ('max_width_absolute_difference','oriented_area_angle_deg','direct_arclength_absolute_difference','min_residual_norm_absolute_difference'):
            t=cross.pivot_table(index=['seed','kappa_rule','method'],columns=['level_a','level_b'],values=column)
            ratio=t[(1,2)]/t[(2,4)]
            ratios[column]={'min':float(ratio.min()),'median':float(ratio.median()),'max':float(ratio.max())}
        summary={
          'input':input_path.name,'input_sha256':sha(input_path.read_bytes()),
          'manifest_verified':manifest_counts,'crc':'PASS',
          'new_11d_ivps':int(len(phys)),'source_knot_rows':int(len(source)),
          'geometry_rows':int(len(f)),'sample_rows':int(len(samples)),'cross_comparison_rows':int(len(cross)),
          'min_norm_all_levels':float(f.min_residual_norm.min()),
          'min_norm_4x_only':float(f.loc[f.density_factor==4,'min_residual_norm'].min()),
          'max_abs_aligned_11d_scaled_2x4x':float(state_source.Z11_max_scaled_2x4x.max()),
          'max_abs_aligned_source_component_2x4x':float(state_source.g_max_component_abs_2x4x.max()),
          'max_norm_aligned_source_2x4x':float(state_source.g_max_vector_norm_2x4x.max()),
          'max_abs_aligned_primitive_component_2x4x':float(state_source.C_max_component_abs_2x4x.max()),
          'max_abs_arc_reconstruction_error':float(checks.arc_error.max()),
          'max_abs_oriented45_reconstruction_error':float(checks.oriented_polygon45_error.max()),
          'max_abs_unit_norm_error':float(checks.max_unit_norm_error.max()),
          'max_abs_cross_area_angle_error_deg':float(verification.area_angle_error_deg.max()),
          'max_2x4x_width_diff':float(cross.loc[(cross.level_a==2)&(cross.level_b==4),'max_width_absolute_difference'].max()),
          'max_2x4x_area_angle_deg':float(cross.loc[(cross.level_a==2)&(cross.level_b==4),'oriented_area_angle_deg'].max()),
          'max_2x4x_arclength_diff_rad':float(cross.loc[(cross.level_a==2)&(cross.level_b==4),'direct_arclength_absolute_difference'].max()),
          'max_2x4x_min_norm_diff':float(cross.loc[(cross.level_a==2)&(cross.level_b==4),'min_residual_norm_absolute_difference'].max()),
          'max_2x_source_trap_nodal_drift':float(source.loc[source.density_factor==2,'max_sampled_source_integral_nodal_drift'].max()),
          'max_4x_source_trap_nodal_drift':float(source.loc[source.density_factor==4,'max_sampled_source_integral_nodal_drift'].max()),
          'width_sign_changes_total':int(f.width_sign_changes.sum()),
          'width_candidate_switches_total':int(f.width_candidate_switches.sum()),
          'width_bounds_total':int(f.num_width_bounds.sum()),
          'ratio_1x2x_to_2x4x':ratios,
          'scope':'Independently checks archive, sampled 11D/source/10D arrays, curves, wedge and CSVs. No 11D reintegration; no material holonomy certification.'
        }
        return summary,checks,state_source,verification

if __name__=='__main__':
    inp=sys.argv[1] if len(sys.argv)>1 else DEFAULT_NAME
    report,checks,state,verification=main(inp)
    print(json.dumps(report,indent=2))
    if len(sys.argv)>2:
        output=Path(sys.argv[2]);output.mkdir(parents=True,exist_ok=True)
        (output/'independent_report.json').write_text(json.dumps(report,indent=2)+'\n')
        checks.to_csv(output/'independent_geometry_checks.csv',index=False)
        state.to_csv(output/'independent_source_state_checks.csv',index=False)
        verification.to_csv(output/'independent_cross_checks.csv',index=False)
